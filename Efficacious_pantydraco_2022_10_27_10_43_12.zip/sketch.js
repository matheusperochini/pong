// variaveis da bolinha
let xbolinha = 300;
let ybolinha = 200;
let diametro = 28;
let raio = diametro / 2 ;


//velocidade da bolinha
let velocidadeXBolinha = 6;
let velocidadeYBolinha = 6;
let raquetecomprimento = 10;
let raquetealtura = 90;

//Variaveis da raquete
let xraquete = 5;
let yraquete = 150;
 
let colidiu = false;

//let placar do jogo
let meusPontos = 0;
let pontosDoOponente = 0;

//Variaveis do oponente
let xraqueteoponente = 585;
let yraqueteoponente = 150;  
let velocidadeyoponente;

//sons do jogo
let raquetada;
let ponto;
let trila;

function preload(){
 trilha = loadSound("trilha.mp3");
 ponto = loadSound("ponto.mp3");
 raquetada = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(600, 400);
  trilha.loop();

}
function draw() {
 background(0);
 mostraBolinha();
 movimentaBolinha();
 verificaColisaoBorda();
 mostraraquete(xraquete, yraquete);
 movimentaminharaquete();
 //verificacolisaoraquete();
 verificacolisaoraquete(xraquete, yraquete);
 mostraraquete(xraqueteoponente, yraqueteoponente);
 movimentaraqueteoponente();
 verificacolisaoraquete(xraqueteoponente, yraqueteoponente);
 incluiplacar();
 marcaPonto();
}

  function mostraBolinha(){
  circle(xbolinha, ybolinha, diametro);
}
 function movimentaBolinha(){
  xbolinha += velocidadeXBolinha;
  ybolinha += velocidadeYBolinha;
 }  
  function verificaColisaoBorda(){  
    if (xbolinha + raio> width ||
     xbolinha - raio< 0){
    velocidadeXBolinha *= -1;
  }
    if (ybolinha + raio> height ||
     ybolinha - raio < 0){
    velocidadeYBolinha *= -1;
  } 
 } 
      
  function mostraraquete(x,y){
    rect(x, y, raquetecomprimento, raquetealtura)
}      
  function movimentaminharaquete(){
     if (keyIsDown(UP_ARROW)){
       yraquete -= 10; 
 } 
     if (keyIsDown(DOWN_ARROW)){
       yraquete += 10;                                }
}
  function verificacolisaoraquete(){
    if (xbolinha - raio < xraquete + raquetecomprimento && ybolinha - raio < yraquete + raquetealtura && ybolinha + raio > yraquete  ){
  velocidadeXBolinha *= -1;
  raquetada.play();
}
 }
 function verificacolisaoraquete(x,y){
    colidiu =   collideRectCircle(x,y,raquetecomprimento,raquetealtura,xbolinha,ybolinha,raio);
    if (colidiu)   {  
      velocidadeXBolinha *= -1;
  
   raquetada.play();
 }
}
function movimentaraqueteoponente(){
  velocidadeyoponente = ybolinha - yraqueteoponente - raquetecomprimento / 2 - 30;
 yraqueteoponente += velocidadeyoponente
 }

function incluiplacar(){
 textSize(20);
  fill(255)
 text(meusPontos, 150, 26);
 text(pontosDoOponente, 450, 26)
}
 function marcaPonto(){
 if (xbolinha > 590){
   meusPontos +=  1;
}
 if (xbolinha < 13){
   pontosDoOponente +=  1;
 }  
}   
   
   
   
   
   
   
   
   
   
   
